'use strict';

var assistant = require("./AssistantIntegrate");
function watsoninputaction(params) {
  var context = {};
  var response = null;
  assistant.asyncmessage("Yes", context).then(responseArg=>{
    console.log("response "+ responseArg);
    response = responseArg;
  })
  .catch(err => {
    console.error(JSON.stringify(err));
    response = err;
  });
  return response;
}
exports.watsoninputaction = watsoninputaction;
